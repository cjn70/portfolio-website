var express = require("express");
var app     = express();
var path    = require("path");
var mysql = require('mysql');
var router = express.Router();
var session = require('express-session')
var bodyParser = require('body-parser');
var nunjucks = require('nunjucks');
var pug = require('pug');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
	 service: 'gmail',
	 auth: {
		 user: 'craignatoli.1@gmail.com',
		 pass: 'ccm0883680'
	 },
	 tls: {
				 rejectUnauthorized: false
		 }
 });
app.set('views',path.join(__dirname,'views'));

app.set('view engine','hbs')



app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'static')));
router.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/intro.html'));


});
router.get('/systems',function(req,res){
  res.sendFile(path.join(__dirname+'/systems.html'));

});
router.get('/resume',function(req,res){
  res.sendFile(path.join(__dirname+'/craigport.html'));

});
router.get('/prinfo',function(req,res){
  res.sendFile(path.join(__dirname+'/prinfo.html'));

});
router.get('/AI',function(req,res){
  res.sendFile(path.join(__dirname+'/AI.html'));

});
router.get('/download',function(req,res){
  res.download(path.join(__dirname+'/Craig NatoliResume.pdf'));

});

app.use("/",router);
app.post('/email',function(req,res){
	var email = req.body.email;
	var subject = req.body.subject;
	var message = req.body.message
	console.log(email);
	var mailOptions = {
	  from: email,
	  to: 'cnatolicraig@aol.com',
	  subject:  subject,
	  text: message +' \n Email From Sender: '+  email
	};
	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	    console.log(error);
	  } else {
	    console.log('Email sent: ' + info.response);
	  }
	});
	res.redirect('/');
})
app.post('/back',function(req,res){
	res.redirect('/');
})
  app.listen(8080);
  console.log("Running at Port 8080");
