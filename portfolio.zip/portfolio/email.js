var nodemailer = require('nodemailer');
var express = require("express");
var app     = express();
var transporter = nodemailer.createTransport({
 // pool: true,
  //host: 'smtp.aol.com',
  //port: 25,
  service: 'gmail',
  //secure: false,
  //port: 25,
  auth: {
    user: 'craignatoli.1@gmail.com',
    pass: 'ccm0883680'
  },
  tls: {
        rejectUnauthorized: false
    }
});
var mailOptions = {
  from: 'laxman15@optimum.net',
  to: 'cnatolicraig@aol.com',
 // subject: 'Sending Email using Node.js',
 //text: 'That was easy!'
 subject: req.session.subject = subject,
 text: req.session.message = username
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
app.listen(8080);
console.log("Running at Port 8080");
